"use client"

import { useState, useEffect } from "react"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { ProductCard } from "@/components/products/product-card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Filter } from "lucide-react"

// Mock products data
const allProducts = [
  {
    id: "1",
    name: "Chocolate Fudge Cake",
    description: "Rich and decadent chocolate cake with fudge frosting",
    price: 45.99,
    originalPrice: 55.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Cakes",
    rating: 4.8,
    reviews: 124,
    isNew: true,
    isBestseller: false,
  },
  {
    id: "2",
    name: "Artisan Chocolate Box",
    description: "Premium selection of handcrafted chocolates",
    price: 29.99,
    originalPrice: null,
    image: "/placeholder.svg?height=300&width=300",
    category: "Chocolates",
    rating: 4.9,
    reviews: 89,
    isNew: false,
    isBestseller: true,
  },
  {
    id: "3",
    name: "Rainbow Candy Mix",
    description: "Colorful assortment of premium candies",
    price: 19.99,
    originalPrice: 24.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Candies",
    rating: 4.6,
    reviews: 156,
    isNew: false,
    isBestseller: false,
  },
  {
    id: "4",
    name: "Vanilla Birthday Cake",
    description: "Classic vanilla cake perfect for celebrations",
    price: 39.99,
    originalPrice: null,
    image: "/placeholder.svg?height=300&width=300",
    category: "Cakes",
    rating: 4.7,
    reviews: 203,
    isNew: false,
    isBestseller: true,
  },
  {
    id: "5",
    name: "Dark Chocolate Truffles",
    description: "Luxurious dark chocolate truffles with various fillings",
    price: 34.99,
    originalPrice: null,
    image: "/placeholder.svg?height=300&width=300",
    category: "Chocolates",
    rating: 4.9,
    reviews: 67,
    isNew: true,
    isBestseller: false,
  },
  {
    id: "6",
    name: "Gummy Bear Paradise",
    description: "Assorted gummy bears in multiple flavors",
    price: 15.99,
    originalPrice: 19.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Candies",
    rating: 4.4,
    reviews: 234,
    isNew: false,
    isBestseller: false,
  },
  {
    id: "7",
    name: "Red Velvet Cupcakes",
    description: "Set of 12 red velvet cupcakes with cream cheese frosting",
    price: 28.99,
    originalPrice: null,
    image: "/placeholder.svg?height=300&width=300",
    category: "Cakes",
    rating: 4.6,
    reviews: 145,
    isNew: false,
    isBestseller: true,
  },
  {
    id: "8",
    name: "Milk Chocolate Hearts",
    description: "Heart-shaped milk chocolates perfect for gifts",
    price: 22.99,
    originalPrice: 27.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Chocolates",
    rating: 4.5,
    reviews: 98,
    isNew: false,
    isBestseller: false,
  },
]

export default function ProductsPage() {
  const [products, setProducts] = useState(allProducts)
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [sortBy, setSortBy] = useState("name")
  const [showFilters, setShowFilters] = useState(false)

  const categories = ["all", "Cakes", "Chocolates", "Candies"]

  useEffect(() => {
    let filtered = allProducts

    // Filter by search query
    if (searchQuery) {
      filtered = filtered.filter(
        (product) =>
          product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          product.description.toLowerCase().includes(searchQuery.toLowerCase()),
      )
    }

    // Filter by category
    if (selectedCategory !== "all") {
      filtered = filtered.filter((product) => product.category === selectedCategory)
    }

    // Sort products
    filtered = [...filtered].sort((a, b) => {
      switch (sortBy) {
        case "price-low":
          return a.price - b.price
        case "price-high":
          return b.price - a.price
        case "rating":
          return b.rating - a.rating
        case "newest":
          return b.isNew ? 1 : -1
        default:
          return a.name.localeCompare(b.name)
      }
    })

    setProducts(filtered)
  }, [searchQuery, selectedCategory, sortBy])

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 container px-4 py-8 mx-auto">
        <div className="space-y-8">
          {/* Page Header */}
          <div className="space-y-4">
            <h1 className="text-3xl font-bold">All Products</h1>
            <p className="text-muted-foreground">Discover our complete collection of premium sweets and desserts</p>
          </div>

          {/* Search and Filters */}
          <div className="flex flex-col lg:flex-row gap-4 items-start lg:items-center justify-between">
            <div className="flex flex-col sm:flex-row gap-4 flex-1 max-w-2xl">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search products..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>

              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-full sm:w-48">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category} value={category}>
                      {category === "all" ? "All Categories" : category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center gap-4">
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="name">Name A-Z</SelectItem>
                  <SelectItem value="price-low">Price: Low to High</SelectItem>
                  <SelectItem value="price-high">Price: High to Low</SelectItem>
                  <SelectItem value="rating">Highest Rated</SelectItem>
                  <SelectItem value="newest">Newest First</SelectItem>
                </SelectContent>
              </Select>

              <Button variant="outline" onClick={() => setShowFilters(!showFilters)} className="lg:hidden">
                <Filter className="h-4 w-4 mr-2" />
                Filters
              </Button>
            </div>
          </div>

          {/* Results Count */}
          <div className="text-sm text-muted-foreground">
            Showing {products.length} of {allProducts.length} products
          </div>

          {/* Products Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>

          {/* No Results */}
          {products.length === 0 && (
            <div className="text-center py-16">
              <div className="space-y-4">
                <h3 className="text-xl font-semibold">No products found</h3>
                <p className="text-muted-foreground">Try adjusting your search or filter criteria</p>
                <Button
                  onClick={() => {
                    setSearchQuery("")
                    setSelectedCategory("all")
                  }}
                >
                  Clear Filters
                </Button>
              </div>
            </div>
          )}
        </div>
      </main>
      <Footer />
    </div>
  )
}
