import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Separator } from "@/components/ui/separator"

interface ProductFiltersProps {
  onFiltersChange: (filters: any) => void
}

export function ProductFilters({ onFiltersChange }: ProductFiltersProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Filters</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Categories */}
        <div className="space-y-3">
          <h4 className="font-medium">Categories</h4>
          <div className="space-y-2">
            {["Cakes", "Chocolates", "Candies", "Cookies"].map((category) => (
              <div key={category} className="flex items-center space-x-2">
                <Checkbox id={category} />
                <Label htmlFor={category}>{category}</Label>
              </div>
            ))}
          </div>
        </div>

        <Separator />

        {/* Price Range */}
        <div className="space-y-3">
          <h4 className="font-medium">Price Range</h4>
          <div className="px-2">
            <Slider defaultValue={[0, 100]} max={100} step={1} className="w-full" />
            <div className="flex justify-between text-sm text-muted-foreground mt-2">
              <span>$0</span>
              <span>$100+</span>
            </div>
          </div>
        </div>

        <Separator />

        {/* Special Offers */}
        <div className="space-y-3">
          <h4 className="font-medium">Special Offers</h4>
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <Checkbox id="on-sale" />
              <Label htmlFor="on-sale">On Sale</Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox id="new-arrivals" />
              <Label htmlFor="new-arrivals">New Arrivals</Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox id="bestsellers" />
              <Label htmlFor="bestsellers">Bestsellers</Label>
            </div>
          </div>
        </div>

        <Separator />

        {/* Rating */}
        <div className="space-y-3">
          <h4 className="font-medium">Rating</h4>
          <div className="space-y-2">
            {[4, 3, 2, 1].map((rating) => (
              <div key={rating} className="flex items-center space-x-2">
                <Checkbox id={`rating-${rating}`} />
                <Label htmlFor={`rating-${rating}`} className="flex items-center">
                  {rating}+ Stars
                </Label>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
