"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { useCart } from "@/contexts/cart-context"
import { useAuth } from "@/contexts/auth-context"
import { Heart, ShoppingCart, Star } from "lucide-react"
import Link from "next/link"
import { useToast } from "@/hooks/use-toast"

// Mock featured products data
const featuredProducts = [
  {
    id: "1",
    name: "Chocolate Fudge Cake",
    description: "Rich and decadent chocolate cake with fudge frosting",
    price: 45.99,
    originalPrice: 55.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Cakes",
    rating: 4.8,
    reviews: 124,
    isNew: true,
    isBestseller: false,
  },
  {
    id: "2",
    name: "Artisan Chocolate Box",
    description: "Premium selection of handcrafted chocolates",
    price: 29.99,
    originalPrice: null,
    image: "/placeholder.svg?height=300&width=300",
    category: "Chocolates",
    rating: 4.9,
    reviews: 89,
    isNew: false,
    isBestseller: true,
  },
  {
    id: "3",
    name: "Rainbow Candy Mix",
    description: "Colorful assortment of premium candies",
    price: 19.99,
    originalPrice: 24.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Candies",
    rating: 4.6,
    reviews: 156,
    isNew: false,
    isBestseller: false,
  },
  {
    id: "4",
    name: "Vanilla Birthday Cake",
    description: "Classic vanilla cake perfect for celebrations",
    price: 39.99,
    originalPrice: null,
    image: "/placeholder.svg?height=300&width=300",
    category: "Cakes",
    rating: 4.7,
    reviews: 203,
    isNew: false,
    isBestseller: true,
  },
]

export function FeaturedProducts() {
  const { addToCart } = useCart()
  const { user } = useAuth()
  const { toast } = useToast()
  const [wishlist, setWishlist] = useState<string[]>([])

  const handleAddToCart = (product: (typeof featuredProducts)[0]) => {
    if (!user) {
      toast({
        title: "Login Required",
        description: "Please login to add items to cart",
        variant: "destructive",
      })
      return
    }

    addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      quantity: 1,
    })

    toast({
      title: "Added to Cart",
      description: `${product.name} has been added to your cart`,
    })
  }

  const toggleWishlist = (productId: string) => {
    if (!user) {
      toast({
        title: "Login Required",
        description: "Please login to add items to wishlist",
        variant: "destructive",
      })
      return
    }

    setWishlist((prev) => (prev.includes(productId) ? prev.filter((id) => id !== productId) : [...prev, productId]))
  }

  return (
    <section className="py-24 bg-muted/30">
      <div className="container px-4 mx-auto">
        <div className="text-center space-y-4 mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold">Featured Products</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Discover our most popular and newest sweet treats
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredProducts.map((product) => (
            <Card key={product.id} className="group hover:shadow-lg transition-all duration-300 overflow-hidden">
              <div className="relative">
                <img
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                />

                {/* Badges */}
                <div className="absolute top-3 left-3 flex flex-col gap-2">
                  {product.isNew && <Badge className="bg-green-500 hover:bg-green-600">New</Badge>}
                  {product.isBestseller && <Badge className="bg-orange-500 hover:bg-orange-600">Bestseller</Badge>}
                  {product.originalPrice && (
                    <Badge variant="destructive">
                      {Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)}% OFF
                    </Badge>
                  )}
                </div>

                {/* Wishlist Button */}
                <Button
                  size="icon"
                  variant="ghost"
                  className="absolute top-3 right-3 bg-white/80 hover:bg-white"
                  onClick={() => toggleWishlist(product.id)}
                >
                  <Heart className={`h-4 w-4 ${wishlist.includes(product.id) ? "fill-red-500 text-red-500" : ""}`} />
                </Button>
              </div>

              <CardContent className="p-6">
                <div className="space-y-3">
                  <div>
                    <Badge variant="secondary" className="text-xs mb-2">
                      {product.category}
                    </Badge>
                    <h3 className="font-semibold text-lg leading-tight">
                      <Link href={`/products/${product.id}`} className="hover:text-primary transition-colors">
                        {product.name}
                      </Link>
                    </h3>
                    <p className="text-sm text-muted-foreground line-clamp-2">{product.description}</p>
                  </div>

                  {/* Rating */}
                  <div className="flex items-center gap-2">
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`h-3 w-3 ${i < Math.floor(product.rating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"}`}
                        />
                      ))}
                    </div>
                    <span className="text-xs text-muted-foreground">
                      {product.rating} ({product.reviews})
                    </span>
                  </div>

                  {/* Price */}
                  <div className="flex items-center gap-2">
                    <span className="text-lg font-bold text-primary">${product.price}</span>
                    {product.originalPrice && (
                      <span className="text-sm text-muted-foreground line-through">${product.originalPrice}</span>
                    )}
                  </div>

                  {/* Add to Cart Button */}
                  <Button className="w-full" onClick={() => handleAddToCart(product)}>
                    <ShoppingCart className="mr-2 h-4 w-4" />
                    Add to Cart
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button size="lg" variant="outline" asChild>
            <Link href="/products">View All Products</Link>
          </Button>
        </div>
      </div>
    </section>
  )
}
