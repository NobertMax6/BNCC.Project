import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"

const categories = [
  {
    id: 1,
    name: "Cakes",
    description: "Birthday, wedding, and custom cakes",
    image: "/placeholder.svg?height=200&width=300",
    count: 150,
    color: "from-pink-500 to-rose-500",
  },
  {
    id: 2,
    name: "Chocolates",
    description: "Premium artisan chocolates",
    image: "/placeholder.svg?height=200&width=300",
    count: 200,
    color: "from-amber-500 to-orange-500",
  },
  {
    id: 3,
    name: "Candies",
    description: "Colorful and delicious candies",
    image: "/placeholder.svg?height=200&width=300",
    count: 180,
    color: "from-purple-500 to-indigo-500",
  },
  {
    id: 4,
    name: "Cookies",
    description: "Freshly baked cookies",
    image: "/placeholder.svg?height=200&width=300",
    count: 120,
    color: "from-green-500 to-teal-500",
  },
]

export function Categories() {
  return (
    <section className="py-24 bg-background">
      <div className="container px-4 mx-auto">
        <div className="text-center space-y-4 mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold">Sweet Categories</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Explore our carefully curated selection of premium sweets and desserts
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {categories.map((category) => (
            <Link key={category.id} href={`/categories/${category.name.toLowerCase()}`}>
              <Card className="group hover:shadow-lg transition-all duration-300 overflow-hidden">
                <div className="relative">
                  <img
                    src={category.image || "/placeholder.svg"}
                    alt={category.name}
                    className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div
                    className={`absolute inset-0 bg-gradient-to-t ${category.color} opacity-20 group-hover:opacity-30 transition-opacity`}
                  ></div>
                </div>
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold mb-2">{category.name}</h3>
                  <p className="text-muted-foreground text-sm mb-3">{category.description}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-primary">{category.count} products</span>
                    <span className="text-sm text-muted-foreground group-hover:text-primary transition-colors">
                      Explore →
                    </span>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}
